import { useEffect, useRef } from 'react';

const KATAKANA = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
const DIGITS = '0123456789';
const CHARS = KATAKANA + DIGITS + '!@#$%^&*(){}[]<>';

interface Drop {
  x: number;
  y: number;
  speed: number;
  chars: string[];
  length: number;
  opacity: number;
}

export function MatrixRain({ fadeOut = false }: { fadeOut?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const fontSize = 14;
    const columns = Math.ceil(canvas.width / fontSize);
    
    const drops: Drop[] = Array.from({ length: columns }, (_, i) => ({
      x: i * fontSize,
      y: Math.random() * -canvas.height,
      speed: 2 + Math.random() * 6,
      chars: Array.from({ length: 20 + Math.floor(Math.random() * 15) }, () =>
        CHARS[Math.floor(Math.random() * CHARS.length)]
      ),
      length: 15 + Math.floor(Math.random() * 20),
      opacity: 0.3 + Math.random() * 0.7,
    }));

    let globalAlpha = 1;

    function animate() {
      if (!ctx || !canvas) return;

      if (fadeOut) {
        globalAlpha = Math.max(0, globalAlpha - 0.02);
      }

      // Semi-transparent black to create trailing effect
      ctx.fillStyle = `rgba(0, 0, 0, 0.05)`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = `${fontSize}px "JetBrains Mono", monospace`;

      for (const drop of drops) {
        for (let i = 0; i < drop.length; i++) {
          const y = drop.y - i * fontSize;
          if (y < -fontSize || y > canvas.height + fontSize) continue;

          const charIndex = (Math.floor(drop.y / fontSize) + i) % drop.chars.length;
          
          // Randomly change characters
          if (Math.random() > 0.95) {
            drop.chars[charIndex] = CHARS[Math.floor(Math.random() * CHARS.length)];
          }

          // Head of the drop is bright
          if (i === 0) {
            ctx.fillStyle = `rgba(236, 239, 244, ${drop.opacity * globalAlpha})`;
            ctx.shadowBlur = 15;
            ctx.shadowColor = '#88C0D0';
          } else if (i < 3) {
            ctx.fillStyle = `rgba(136, 192, 208, ${(drop.opacity * 0.9) * globalAlpha})`;
            ctx.shadowBlur = 8;
            ctx.shadowColor = '#88C0D0';
          } else {
            const fade = 1 - (i / drop.length);
            ctx.fillStyle = `rgba(163, 190, 140, ${(fade * drop.opacity * 0.6) * globalAlpha})`;
            ctx.shadowBlur = 0;
          }

          ctx.fillText(drop.chars[charIndex], drop.x, y);
          ctx.shadowBlur = 0;
        }

        drop.y += drop.speed;

        if (drop.y > canvas.height + drop.length * fontSize) {
          drop.y = Math.random() * -500;
          drop.speed = 2 + Math.random() * 6;
          drop.opacity = 0.3 + Math.random() * 0.7;
        }
      }

      if (globalAlpha > 0) {
        animRef.current = requestAnimationFrame(animate);
      }
    }

    animate();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [fadeOut]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0"
      style={{ zIndex: 0 }}
    />
  );
}
