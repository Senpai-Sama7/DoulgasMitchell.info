import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { getAsciiText, getRandomScrambleChar } from '../utils/asciiArt';

interface AsciiTextRevealProps {
  text: string;
  color?: string;
  glowColor?: string;
  delay?: number;
  onComplete?: () => void;
  scrambleDuration?: number;
  revealStyle?: 'wave' | 'random' | 'left-right' | 'center-out';
}

export function AsciiTextReveal({
  text,
  color = '#88C0D0',
  glowColor = 'rgba(136, 192, 208, 0.5)',
  delay = 0,
  onComplete,
  scrambleDuration = 2000,
  revealStyle: _revealStyle = 'wave',
}: AsciiTextRevealProps) {
  void _revealStyle;
  const asciiLines = useMemo(() => getAsciiText(text), [text]);
  const totalCols = asciiLines[0]?.length || 0;
  const [revealedCols, setRevealedCols] = useState(0);
  const [scrambleGrid, setScrambleGrid] = useState<string[][]>([]);
  const [started, setStarted] = useState(false);
  const [glitchActive, setGlitchActive] = useState(false);
  const completedRef = useRef(false);

  // Initialize scramble grid
  useEffect(() => {
    const grid = asciiLines.map(line =>
      Array.from({ length: line.length }, () => getRandomScrambleChar())
    );
    setScrambleGrid(grid);
  }, [asciiLines]);

  // Delay start
  useEffect(() => {
    const timer = setTimeout(() => setStarted(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  // Scramble animation for unrevealed characters
  useEffect(() => {
    if (!started) return;
    const interval = setInterval(() => {
      setScrambleGrid(prev =>
        prev.map((row, ri) =>
          row.map((_, ci) => {
            if (ci < revealedCols) return asciiLines[ri]?.[ci] || ' ';
            return getRandomScrambleChar();
          })
        )
      );
    }, 50);
    return () => clearInterval(interval);
  }, [started, revealedCols, asciiLines]);

  // Reveal columns progressively
  useEffect(() => {
    if (!started) return;
    const colsPerTick = Math.max(1, Math.ceil(totalCols / (scrambleDuration / 30)));
    const interval = setInterval(() => {
      setRevealedCols(prev => {
        const next = prev + colsPerTick;
        if (next >= totalCols) {
          clearInterval(interval);
          if (!completedRef.current) {
            completedRef.current = true;
            // Trigger a quick glitch effect on completion
            setGlitchActive(true);
            setTimeout(() => setGlitchActive(false), 300);
            setTimeout(() => onComplete?.(), 500);
          }
          return totalCols;
        }
        return next;
      });
    }, 30);
    return () => clearInterval(interval);
  }, [started, totalCols, scrambleDuration, onComplete]);

  // Random glitch pulses during reveal
  useEffect(() => {
    if (!started || revealedCols >= totalCols) return;
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        setGlitchActive(true);
        setTimeout(() => setGlitchActive(false), 100);
      }
    }, 500);
    return () => clearInterval(interval);
  }, [started, revealedCols, totalCols]);

  const getCharStyle = useCallback(
    (_row: number, _col: number, char: string, isRevealed: boolean) => {
      void _row; void _col;
      const isBlock = char === '█' || char === '▄' || char === '▀';

      if (!isRevealed) {
        return {
          color: `rgba(136, 192, 208, ${0.1 + Math.random() * 0.3})`,
          textShadow: 'none',
          opacity: started ? 0.6 : 0,
          transition: 'opacity 0.3s',
        };
      }

      if (isBlock) {
        return {
          color: color,
          textShadow: `0 0 8px ${glowColor}, 0 0 20px ${glowColor}`,
          opacity: 1,
          transition: 'all 0.2s ease-out',
        };
      }

      return {
        color: 'rgba(236, 239, 244, 0.3)',
        textShadow: 'none',
        opacity: 1,
        transition: 'all 0.2s ease-out',
      };
    },
    [started, color, glowColor]
  );

  if (!started) return null;

  return (
    <div className="relative select-none">
      {/* Glitch layer 1 */}
      {glitchActive && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            transform: `translate(${Math.random() * 4 - 2}px, ${Math.random() * 4 - 2}px)`,
            opacity: 0.7,
            mixBlendMode: 'screen',
          }}
        >
          <pre
            className="font-mono leading-none"
            style={{
              fontSize: 'clamp(4px, 1.1vw, 14px)',
              color: '#BF616A',
              letterSpacing: '0.05em',
            }}
          >
            {asciiLines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </pre>
        </div>
      )}

      {/* Glitch layer 2 */}
      {glitchActive && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            transform: `translate(${Math.random() * -4 + 2}px, ${Math.random() * -4 + 2}px)`,
            opacity: 0.5,
            mixBlendMode: 'screen',
          }}
        >
          <pre
            className="font-mono leading-none"
            style={{
              fontSize: 'clamp(4px, 1.1vw, 14px)',
              color: '#A3BE8C',
              letterSpacing: '0.05em',
            }}
          >
            {asciiLines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </pre>
        </div>
      )}

      {/* Main text */}
      <pre
        className="font-mono leading-none relative z-10"
        style={{
          fontSize: 'clamp(4px, 1.1vw, 14px)',
          letterSpacing: '0.05em',
        }}
      >
        {scrambleGrid.map((row, ri) => (
          <div key={ri} className="whitespace-pre">
            {row.map((char, ci) => {
              const isRevealed = ci < revealedCols;
              const displayChar = isRevealed ? (asciiLines[ri]?.[ci] || ' ') : char;
              const style = getCharStyle(ri, ci, displayChar, isRevealed);

              return (
                <span key={ci} style={style} className="inline-block ascii-char">
                  {displayChar}
                </span>
              );
            })}
          </div>
        ))}
      </pre>

      {/* Scan line effect on the reveal edge */}
      {revealedCols < totalCols && revealedCols > 0 && (
        <div
          className="absolute top-0 bottom-0 w-px pointer-events-none"
          style={{
            left: `${(revealedCols / totalCols) * 100}%`,
            background: `linear-gradient(to bottom, transparent, ${color}, transparent)`,
            boxShadow: `0 0 15px ${glowColor}, 0 0 30px ${glowColor}`,
            opacity: 0.8,
          }}
        />
      )}
    </div>
  );
}
