import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';

const NORD = {
  bg: '#2E3440',
  fg: '#ECEFF4',
  cyan: '#88C0D0',
  blue: '#81A1C1',
  red: '#BF616A',
  green: '#A3BE8C',
  yellow: '#EBCB8B',
  purple: '#B48EAD',
  dark0: '#2E3440',
  dark1: '#3B4252',
  dark2: '#434C5E',
  dark3: '#4C566A',
};

const SKILLS = [
  { name: 'AI & Machine Learning', level: 95, color: NORD.cyan },
  { name: 'Systems Architecture', level: 90, color: NORD.blue },
  { name: 'Operations Analysis', level: 92, color: NORD.green },
  { name: 'Cloud Infrastructure', level: 88, color: NORD.yellow },
  { name: 'Data Engineering', level: 85, color: NORD.purple },
];

const CERTIFICATIONS = [
  { name: 'Google AI Certified', icon: '🏆' },
  { name: 'Anthropic Certified', icon: '🎯' },
];

const PROJECTS = [
  {
    title: 'Neural Pipeline',
    desc: 'Enterprise AI orchestration system',
    tags: ['Python', 'TensorFlow', 'K8s'],
    status: 'ACTIVE',
  },
  {
    title: 'Quantum Scheduler',
    desc: 'Distributed task optimization engine',
    tags: ['Rust', 'gRPC', 'Redis'],
    status: 'DEPLOYED',
  },
  {
    title: 'Synapse Framework',
    desc: 'Real-time analytics platform',
    tags: ['Go', 'ClickHouse', 'React'],
    status: 'BETA',
  },
];

export function LandingPage() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div
      className="min-h-screen w-full"
      style={{ backgroundColor: '#0a0a0f', color: NORD.fg }}
    >
      {/* Subtle grid background */}
      <div
        className="fixed inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(${NORD.cyan} 1px, transparent 1px),
            linear-gradient(90deg, ${NORD.cyan} 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
        }}
      />

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12"
      >
        {/* Header */}
        <motion.header variants={itemVariants} className="flex items-center justify-between mb-12 sm:mb-16">
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center font-display font-bold text-sm sm:text-base"
              style={{ backgroundColor: NORD.cyan + '20', color: NORD.cyan, border: `1px solid ${NORD.cyan}40` }}
            >
              DM
            </div>
            <div className="font-mono text-[10px] sm:text-xs" style={{ color: NORD.blue, opacity: 0.5 }}>
              <div>SYSTEM: ONLINE</div>
              <div>{time.toLocaleTimeString('en-US', { hour12: false })}</div>
            </div>
          </div>
          <nav className="hidden sm:flex items-center gap-6 font-mono text-xs">
            {['About', 'Projects', 'Contact'].map(item => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="hover:opacity-100 transition-opacity uppercase tracking-widest"
                style={{ color: NORD.cyan, opacity: 0.6 }}
              >
                {item}
              </a>
            ))}
          </nav>
        </motion.header>

        {/* Hero */}
        <motion.section variants={itemVariants} className="mb-16 sm:mb-24" id="about">
          <div className="mb-2 font-mono text-xs sm:text-sm" style={{ color: NORD.green }}>
            {'>'} Hello, World. I am
          </div>
          <h1
            className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight leading-none mb-2"
            style={{ color: NORD.fg }}
          >
            DOUGLAS
          </h1>
          <h1
            className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight leading-none mb-6"
            style={{ color: NORD.cyan }}
          >
            MITCHELL
          </h1>
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px flex-1 max-w-24" style={{ backgroundColor: NORD.cyan + '30' }} />
            <span className="font-display text-xs sm:text-sm tracking-[0.3em] uppercase" style={{ color: NORD.yellow }}>
              The Architect
            </span>
            <div className="h-px flex-1 max-w-24" style={{ backgroundColor: NORD.cyan + '30' }} />
          </div>
          <p className="font-mono text-sm sm:text-base max-w-2xl leading-relaxed" style={{ color: NORD.fg, opacity: 0.6 }}>
            Operations Analyst, AI Practitioner, and Systems Architect. Building intelligent systems 
            that bridge the gap between human insight and machine capability. Author and thought leader 
            in the AI transformation space.
          </p>
        </motion.section>

        {/* Skills & Certifications Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 mb-16 sm:mb-24">
          {/* Skills */}
          <motion.div
            variants={itemVariants}
            className="rounded-xl p-5 sm:p-6 border"
            style={{ backgroundColor: NORD.dark1 + '40', borderColor: NORD.dark3 + '40' }}
          >
            <h2 className="font-display text-sm tracking-widest uppercase mb-6" style={{ color: NORD.cyan }}>
              Core Competencies
            </h2>
            <div className="space-y-4">
              {SKILLS.map((skill, i) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                >
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="font-mono text-xs sm:text-sm" style={{ color: NORD.fg, opacity: 0.8 }}>
                      {skill.name}
                    </span>
                    <span className="font-mono text-xs font-bold" style={{ color: skill.color }}>
                      {skill.level}%
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: NORD.dark3 + '40' }}>
                    <motion.div
                      className="h-full rounded-full"
                      style={{ backgroundColor: skill.color }}
                      initial={{ width: 0 }}
                      animate={{ width: `${skill.level}%` }}
                      transition={{ duration: 1.2, delay: 0.8 + i * 0.1, ease: 'easeOut' }}
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Certifications & Stats */}
          <motion.div variants={itemVariants} className="space-y-6">
            <div
              className="rounded-xl p-5 sm:p-6 border"
              style={{ backgroundColor: NORD.dark1 + '40', borderColor: NORD.dark3 + '40' }}
            >
              <h2 className="font-display text-sm tracking-widest uppercase mb-4" style={{ color: NORD.yellow }}>
                Certifications
              </h2>
              <div className="space-y-3">
                {CERTIFICATIONS.map(cert => (
                  <div key={cert.name} className="flex items-center gap-3 font-mono text-sm">
                    <span className="text-lg">{cert.icon}</span>
                    <span style={{ color: NORD.fg, opacity: 0.8 }}>{cert.name}</span>
                    <span className="ml-auto px-2 py-0.5 rounded text-[10px] font-bold" style={{ backgroundColor: NORD.green + '20', color: NORD.green }}>
                      VERIFIED
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Years Exp', value: '10+', color: NORD.cyan },
                { label: 'Projects', value: '50+', color: NORD.green },
                { label: 'Impact', value: '∞', color: NORD.yellow },
              ].map(stat => (
                <div
                  key={stat.label}
                  className="rounded-xl p-4 border text-center"
                  style={{ backgroundColor: NORD.dark1 + '40', borderColor: NORD.dark3 + '40' }}
                >
                  <div className="font-display text-xl sm:text-2xl font-bold mb-1" style={{ color: stat.color }}>
                    {stat.value}
                  </div>
                  <div className="font-mono text-[10px] uppercase tracking-wider" style={{ color: NORD.fg, opacity: 0.4 }}>
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Projects */}
        <motion.section variants={itemVariants} className="mb-16 sm:mb-24" id="projects">
          <h2 className="font-display text-sm tracking-widest uppercase mb-8" style={{ color: NORD.purple }}>
            Featured Projects
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
            {PROJECTS.map((project, i) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 + i * 0.15 }}
                className="rounded-xl p-5 sm:p-6 border group hover:border-opacity-60 transition-all duration-300 cursor-pointer"
                style={{
                  backgroundColor: NORD.dark1 + '30',
                  borderColor: NORD.dark3 + '30',
                }}
                whileHover={{ y: -4, transition: { duration: 0.2 } }}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="font-display text-sm font-bold" style={{ color: NORD.fg }}>
                    {project.title}
                  </span>
                  <span
                    className="px-2 py-0.5 rounded text-[9px] font-bold tracking-wider"
                    style={{
                      backgroundColor: project.status === 'ACTIVE'
                        ? NORD.green + '20'
                        : project.status === 'DEPLOYED'
                          ? NORD.cyan + '20'
                          : NORD.yellow + '20',
                      color: project.status === 'ACTIVE'
                        ? NORD.green
                        : project.status === 'DEPLOYED'
                          ? NORD.cyan
                          : NORD.yellow,
                    }}
                  >
                    {project.status}
                  </span>
                </div>
                <p className="font-mono text-xs mb-4" style={{ color: NORD.fg, opacity: 0.5 }}>
                  {project.desc}
                </p>
                <div className="flex gap-2 flex-wrap">
                  {project.tags.map(tag => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 rounded text-[10px] font-mono"
                      style={{ backgroundColor: NORD.dark3 + '40', color: NORD.blue }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Contact */}
        <motion.section variants={itemVariants} className="mb-12" id="contact">
          <div
            className="rounded-xl p-6 sm:p-8 border text-center"
            style={{ backgroundColor: NORD.dark1 + '20', borderColor: NORD.cyan + '15' }}
          >
            <h2 className="font-display text-lg sm:text-xl tracking-widest uppercase mb-3" style={{ color: NORD.cyan }}>
              Let's Build Something
            </h2>
            <p className="font-mono text-xs sm:text-sm mb-6 max-w-md mx-auto" style={{ color: NORD.fg, opacity: 0.5 }}>
              Available for consulting, architecture reviews, and AI strategy engagements.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 sm:px-8 py-2.5 sm:py-3 rounded-lg font-mono text-xs sm:text-sm font-bold tracking-wider uppercase"
              style={{
                backgroundColor: NORD.cyan + '20',
                color: NORD.cyan,
                border: `1px solid ${NORD.cyan}40`,
              }}
            >
              Initialize Contact
            </motion.button>
          </div>
        </motion.section>

        {/* Footer */}
        <motion.footer variants={itemVariants} className="text-center pb-8">
          <div className="font-mono text-[10px]" style={{ color: NORD.dark3 }}>
            © {new Date().getFullYear()} Douglas Mitchell · The Architect · All systems nominal
          </div>
        </motion.footer>
      </motion.div>
    </div>
  );
}
