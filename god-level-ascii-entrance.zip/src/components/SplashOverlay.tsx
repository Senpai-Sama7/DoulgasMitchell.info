import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MatrixRain } from './MatrixRain';
import { ParticleField } from './ParticleField';
import { AsciiTextReveal } from './AsciiTextReveal';

const NORD = {
  bg: '#2E3440',
  fg: '#ECEFF4',
  cyan: '#88C0D0',
  blue: '#81A1C1',
  red: '#BF616A',
  green: '#A3BE8C',
  yellow: '#EBCB8B',
  purple: '#B48EAD',
};

const SUBTITLE = 'THE ARCHITECT';
const ROLES = [
  'Operations Analyst',
  'AI Practitioner',
  'Systems Architect',
  'Author',
  'Google AI Certified',
  'Anthropic Certified',
];

type Phase = 'boot' | 'matrix' | 'ascii-first' | 'ascii-second' | 'reveal' | 'fade';

interface SplashOverlayProps {
  onComplete?: () => void;
}

// Boot sequence terminal lines
const BOOT_LINES = [
  { text: '> SYSTEM INIT...', delay: 0 },
  { text: '> LOADING KERNEL MODULES...', delay: 200 },
  { text: '> NEURAL NETWORK: ONLINE', delay: 400 },
  { text: '> QUANTUM CORE: SYNCHRONIZED', delay: 600 },
  { text: '> IDENTITY MATRIX: RESOLVING...', delay: 800 },
  { text: '> DECRYPTING PROFILE...', delay: 1000 },
  { text: '> ACCESS GRANTED ■', delay: 1200 },
];

export function SplashOverlay({ onComplete }: SplashOverlayProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [phase, setPhase] = useState<Phase>('boot');
  const [bootLines, setBootLines] = useState<string[]>([]);
  const [matrixFading, setMatrixFading] = useState(false);
  const [firstNameDone, setFirstNameDone] = useState(false);
  const [secondNameDone, setSecondNameDone] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentRole, setCurrentRole] = useState(0);
  const [showSubtitle, setShowSubtitle] = useState(false);
  const [audioVisualizerBars, setAudioVisualizerBars] = useState<number[]>(
    Array.from({ length: 32 }, () => Math.random() * 30 + 5)
  );
  const containerRef = useRef<HTMLDivElement>(null);

  // Lock scroll
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = 'unset'; };
  }, []);

  // Notify parent on complete
  useEffect(() => {
    if (!isVisible) onComplete?.();
  }, [isVisible, onComplete]);

  // Phase: boot sequence
  useEffect(() => {
    if (phase !== 'boot') return;
    
    const timers: NodeJS.Timeout[] = [];
    BOOT_LINES.forEach((line) => {
      timers.push(setTimeout(() => {
        setBootLines(prev => [...prev, line.text]);
      }, line.delay));
    });

    timers.push(setTimeout(() => setPhase('matrix'), 1800));

    return () => timers.forEach(clearTimeout);
  }, [phase]);

  // Phase: matrix rain
  useEffect(() => {
    if (phase !== 'matrix') return;
    const timer = setTimeout(() => {
      setMatrixFading(true);
      setTimeout(() => setPhase('ascii-first'), 800);
    }, 2500);
    return () => clearTimeout(timer);
  }, [phase]);

  // Phase: first name complete
  useEffect(() => {
    if (firstNameDone && phase === 'ascii-first') {
      setTimeout(() => setPhase('ascii-second'), 300);
    }
  }, [firstNameDone, phase]);

  // Phase: second name complete
  useEffect(() => {
    if (secondNameDone && phase === 'ascii-second') {
      setTimeout(() => {
        setPhase('reveal');
        setShowSubtitle(true);
      }, 500);
    }
  }, [secondNameDone, phase]);

  // Progress bar in reveal phase
  useEffect(() => {
    if (phase !== 'reveal') return;
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setPhase('fade'), 800);
          return 100;
        }
        return prev + 1.5;
      });
    }, 40);
    return () => clearInterval(interval);
  }, [phase]);

  // Role rotation in reveal
  useEffect(() => {
    if (phase !== 'reveal' && phase !== 'fade') return;
    const interval = setInterval(() => {
      setCurrentRole(prev => (prev + 1) % ROLES.length);
    }, 700);
    return () => clearInterval(interval);
  }, [phase]);

  // Fake audio visualizer
  useEffect(() => {
    if (phase !== 'reveal' && phase !== 'ascii-first' && phase !== 'ascii-second') return;
    const interval = setInterval(() => {
      setAudioVisualizerBars(prev =>
        prev.map((v) => {
          const target = Math.random() * 40 + 5;
          return v + (target - v) * 0.3;
        })
      );
    }, 80);
    return () => clearInterval(interval);
  }, [phase]);

  // Fade out
  useEffect(() => {
    if (phase !== 'fade') return;
    const timer = setTimeout(() => setIsVisible(false), 1500);
    return () => clearTimeout(timer);
  }, [phase]);

  // Skip handler
  const handleSkip = useCallback(() => {
    setIsVisible(false);
  }, []);

  // Keyboard skip
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === ' ') handleSkip();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleSkip]);

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          ref={containerRef}
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden cursor-pointer"
          style={{ backgroundColor: '#0a0a0f', height: '100dvh' }}
          onClick={handleSkip}
        >
          {/* Matrix Rain Background */}
          {(phase === 'matrix' || phase === 'boot') && (
            <MatrixRain fadeOut={matrixFading} />
          )}

          {/* Particle Field */}
          <ParticleField
            intensity={phase === 'reveal' || phase === 'fade' ? 1.5 : 0.5}
            active={phase !== 'boot'}
          />

          {/* CRT Scanline Overlay */}
          <div className="fixed inset-0 crt-overlay pointer-events-none" style={{ zIndex: 50, opacity: 0.3 }} />

          {/* Horizontal scan line */}
          {(phase === 'ascii-first' || phase === 'ascii-second' || phase === 'reveal') && (
            <motion.div
              className="fixed left-0 right-0 h-px pointer-events-none"
              style={{
                background: `linear-gradient(to right, transparent, ${NORD.cyan}, transparent)`,
                boxShadow: `0 0 20px ${NORD.cyan}, 0 0 40px ${NORD.cyan}`,
                zIndex: 51,
              }}
              animate={{ y: ['-50vh', '50vh'] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            />
          )}

          {/* Vignette */}
          <div
            className="fixed inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,0.7) 100%)',
              zIndex: 2,
            }}
          />

          {/* Corner decorations */}
          <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 52 }}>
            {/* Top-left corner */}
            <div className="absolute top-4 left-4">
              <svg width="40" height="40" viewBox="0 0 40 40">
                <path d="M0 20 L0 0 L20 0" fill="none" stroke={NORD.cyan} strokeWidth="1" opacity="0.5" />
              </svg>
            </div>
            {/* Top-right corner */}
            <div className="absolute top-4 right-4">
              <svg width="40" height="40" viewBox="0 0 40 40">
                <path d="M20 0 L40 0 L40 20" fill="none" stroke={NORD.cyan} strokeWidth="1" opacity="0.5" />
              </svg>
            </div>
            {/* Bottom-left corner */}
            <div className="absolute bottom-4 left-4">
              <svg width="40" height="40" viewBox="0 0 40 40">
                <path d="M0 20 L0 40 L20 40" fill="none" stroke={NORD.cyan} strokeWidth="1" opacity="0.5" />
              </svg>
            </div>
            {/* Bottom-right corner */}
            <div className="absolute bottom-4 right-4">
              <svg width="40" height="40" viewBox="0 0 40 40">
                <path d="M20 40 L40 40 L40 20" fill="none" stroke={NORD.cyan} strokeWidth="1" opacity="0.5" />
              </svg>
            </div>
          </div>

          {/* Main Content Container */}
          <div className="relative z-10 w-full flex flex-col items-center justify-center px-4" style={{ zIndex: 40 }}>
            
            {/* Boot Sequence */}
            {phase === 'boot' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="font-mono text-left max-w-lg w-full"
              >
                <div className="border border-green-500/30 rounded-lg bg-black/60 p-4 sm:p-6 backdrop-blur-sm">
                  <div className="flex items-center gap-2 mb-4 pb-3 border-b border-green-500/20">
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                      <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                    </div>
                    <span className="text-xs text-green-500/60 uppercase tracking-widest ml-2">
                      system_init.sh
                    </span>
                  </div>
                  {bootLines.map((line, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.2 }}
                      className="text-xs sm:text-sm mb-1"
                      style={{ color: line.includes('GRANTED') ? NORD.green : NORD.cyan }}
                    >
                      {line}
                    </motion.div>
                  ))}
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                    className="inline-block text-green-400 text-sm"
                  >
                    █
                  </motion.span>
                </div>
              </motion.div>
            )}

            {/* Terminal Header for ASCII phases */}
            {(phase === 'matrix' || phase === 'ascii-first' || phase === 'ascii-second' || phase === 'reveal' || phase === 'fade') && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="mb-6 sm:mb-8"
              >
                <div className="inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-5 py-2 border border-cyan-500/20 rounded-lg bg-black/40 backdrop-blur-sm">
                  <div className="flex gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-red-500/60" />
                    <div className="w-2 h-2 rounded-full bg-yellow-500/60" />
                    <div className="w-2 h-2 rounded-full bg-green-500/60" />
                  </div>
                  <span className="font-mono text-[10px] sm:text-xs text-cyan-500/50 uppercase tracking-[0.2em]">
                    identity_resolver v2.0
                  </span>
                  <div className="w-px h-3 bg-cyan-500/20" />
                  <motion.div
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-1.5 h-1.5 rounded-full bg-green-500"
                  />
                </div>
              </motion.div>
            )}

            {/* ASCII Art - DOUGLAS */}
            {(phase === 'ascii-first' || phase === 'ascii-second' || phase === 'reveal' || phase === 'fade') && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: phase === 'fade' ? 0.3 : 1 }}
                transition={{ duration: 0.5 }}
                className="mb-2 sm:mb-4"
              >
                <AsciiTextReveal
                  text="DOUGLAS"
                  color={NORD.cyan}
                  glowColor="rgba(136, 192, 208, 0.6)"
                  delay={0}
                  scrambleDuration={1500}
                  onComplete={() => setFirstNameDone(true)}
                />
              </motion.div>
            )}

            {/* ASCII Art - MITCHELL */}
            {(phase === 'ascii-second' || phase === 'reveal' || phase === 'fade') && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: phase === 'fade' ? 0.3 : 1 }}
                transition={{ duration: 0.5 }}
                className="mb-6 sm:mb-8"
              >
                <AsciiTextReveal
                  text="MITCHELL"
                  color={NORD.yellow}
                  glowColor="rgba(235, 203, 139, 0.6)"
                  delay={200}
                  scrambleDuration={1500}
                  onComplete={() => setSecondNameDone(true)}
                />
              </motion.div>
            )}

            {/* Decorative line */}
            {(phase === 'reveal' || phase === 'fade') && (
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="w-48 sm:w-64 md:w-80 h-px mb-4 sm:mb-6 origin-center"
                style={{
                  background: `linear-gradient(to right, transparent, ${NORD.cyan}, ${NORD.yellow}, ${NORD.cyan}, transparent)`,
                  boxShadow: `0 0 10px ${NORD.cyan}40`,
                }}
              />
            )}

            {/* Subtitle */}
            {showSubtitle && (phase === 'reveal' || phase === 'fade') && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="mb-3 sm:mb-4"
              >
                <div className="flex items-center justify-center gap-2 sm:gap-4">
                  <motion.span
                    animate={{ rotate: [0, 90, 180, 270, 360] }}
                    transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
                    className="text-xs sm:text-sm"
                    style={{ color: NORD.cyan, opacity: 0.5 }}
                  >
                    ◆
                  </motion.span>
                  <span
                    className="font-display text-xs sm:text-sm md:text-base tracking-[0.4em] sm:tracking-[0.6em] uppercase animate-pulse-glow"
                    style={{ color: NORD.fg }}
                  >
                    {SUBTITLE}
                  </span>
                  <motion.span
                    animate={{ rotate: [360, 270, 180, 90, 0] }}
                    transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
                    className="text-xs sm:text-sm"
                    style={{ color: NORD.cyan, opacity: 0.5 }}
                  >
                    ◆
                  </motion.span>
                </div>
              </motion.div>
            )}

            {/* Rotating Role */}
            {(phase === 'reveal' || phase === 'fade') && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="mb-5 sm:mb-6 h-6 sm:h-8"
              >
                <div className="flex items-center justify-center gap-2 sm:gap-3">
                  <span className="font-mono text-xs" style={{ color: NORD.green, opacity: 0.6 }}>
                    {'>'}_
                  </span>
                  <AnimatePresence mode="wait">
                    <motion.span
                      key={currentRole}
                      initial={{ opacity: 0, y: 15, filter: 'blur(4px)' }}
                      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                      exit={{ opacity: 0, y: -15, filter: 'blur(4px)' }}
                      transition={{ duration: 0.3 }}
                      className="font-mono text-xs sm:text-sm tracking-wider"
                      style={{ color: NORD.cyan }}
                    >
                      {ROLES[currentRole]}
                    </motion.span>
                  </AnimatePresence>
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                    className="font-mono text-sm"
                    style={{ color: NORD.green }}
                  >
                    █
                  </motion.span>
                </div>
              </motion.div>
            )}

            {/* Audio Visualizer Bar */}
            {(phase === 'reveal' || phase === 'ascii-first' || phase === 'ascii-second') && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-end justify-center gap-[2px] mb-4 sm:mb-6 h-8"
              >
                {audioVisualizerBars.map((height, i) => (
                  <div
                    key={i}
                    className="w-[2px] sm:w-[3px] rounded-t-full transition-all duration-75"
                    style={{
                      height: `${height}%`,
                      backgroundColor: i < audioVisualizerBars.length / 3
                        ? NORD.cyan
                        : i < (audioVisualizerBars.length * 2) / 3
                          ? NORD.blue
                          : NORD.purple,
                      opacity: 0.5 + (height / 100) * 0.5,
                      boxShadow: height > 60 ? `0 0 4px ${NORD.cyan}` : 'none',
                    }}
                  />
                ))}
              </motion.div>
            )}

            {/* Progress Bar */}
            {(phase === 'reveal' || phase === 'fade') && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="w-48 sm:w-64 mx-auto"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[10px] sm:text-xs" style={{ color: NORD.blue, opacity: 0.5 }}>
                    initializing...
                  </span>
                  <span className="font-mono text-[10px] sm:text-xs font-bold" style={{ color: NORD.cyan }}>
                    {Math.floor(progress)}%
                  </span>
                </div>
                <div className="h-1 sm:h-1.5 rounded-full overflow-hidden bg-white/5 backdrop-blur-sm">
                  <motion.div
                    className="h-full rounded-full"
                    style={{
                      background: `linear-gradient(to right, ${NORD.cyan}, ${NORD.blue}, ${NORD.purple})`,
                      boxShadow: `0 0 10px ${NORD.cyan}80`,
                    }}
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.1 }}
                  />
                </div>
                {/* Progress bar detail markers */}
                <div className="flex justify-between mt-1">
                  {[0, 25, 50, 75, 100].map(mark => (
                    <span
                      key={mark}
                      className="font-mono text-[8px]"
                      style={{
                        color: progress >= mark ? NORD.cyan : NORD.blue,
                        opacity: progress >= mark ? 0.7 : 0.2,
                      }}
                    >
                      {mark === 0 ? '|' : mark === 100 ? '|' : '·'}
                    </span>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Bottom HUD */}
          <div className="fixed bottom-0 left-0 right-0 p-4 flex items-end justify-between pointer-events-none" style={{ zIndex: 52 }}>
            {/* Left: coordinates */}
            <div className="font-mono text-[9px] sm:text-[10px] space-y-0.5" style={{ color: NORD.blue, opacity: 0.3 }}>
              <div>LAT: 34.0522°N</div>
              <div>LON: 118.2437°W</div>
              <div>ALT: {Math.floor(Math.random() * 1000 + 100)}m</div>
            </div>

            {/* Center: skip hint */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="text-center pointer-events-auto"
            >
              <p className="font-mono text-[9px] sm:text-[10px]" style={{ color: NORD.blue, opacity: 0.4 }}>
                Press{' '}
                <kbd
                  className="px-1.5 py-0.5 rounded text-[9px] sm:text-[10px] border"
                  style={{
                    backgroundColor: 'rgba(136, 192, 208, 0.08)',
                    borderColor: 'rgba(136, 192, 208, 0.15)',
                    color: NORD.cyan,
                  }}
                >
                  ESC
                </kbd>{' '}
                or click anywhere to skip
              </p>
            </motion.div>

            {/* Right: timestamp */}
            <div className="font-mono text-[9px] sm:text-[10px] text-right space-y-0.5" style={{ color: NORD.blue, opacity: 0.3 }}>
              <div>SYS: NOMINAL</div>
              <div>MEM: {Math.floor(Math.random() * 30 + 60)}%</div>
              <div>CPU: {Math.floor(Math.random() * 20 + 15)}%</div>
            </div>
          </div>

          {/* Radial glow behind text */}
          <div
            className="fixed inset-0 pointer-events-none"
            style={{
              background: `radial-gradient(ellipse at center, rgba(136, 192, 208, 0.08) 0%, transparent 50%)`,
              zIndex: 3,
            }}
          />

          {/* Phase-specific ambient glow */}
          {(phase === 'ascii-first' || phase === 'ascii-second') && (
            <motion.div
              className="fixed inset-0 pointer-events-none"
              animate={{
                background: [
                  'radial-gradient(ellipse at center, rgba(136, 192, 208, 0.05) 0%, transparent 60%)',
                  'radial-gradient(ellipse at center, rgba(136, 192, 208, 0.12) 0%, transparent 60%)',
                  'radial-gradient(ellipse at center, rgba(136, 192, 208, 0.05) 0%, transparent 60%)',
                ],
              }}
              transition={{ duration: 2, repeat: Infinity }}
              style={{ zIndex: 3 }}
            />
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
