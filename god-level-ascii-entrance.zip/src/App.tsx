import { useState, useCallback } from 'react';
import { SplashOverlay } from './components/SplashOverlay';
import { LandingPage } from './components/LandingPage';

export function App() {
  const [splashComplete, setSplashComplete] = useState(false);

  const handleSplashComplete = useCallback(() => {
    setSplashComplete(true);
    document.body.style.overflow = 'unset';
  }, []);

  return (
    <>
      {!splashComplete && <SplashOverlay onComplete={handleSplashComplete} />}
      {splashComplete && <LandingPage />}
    </>
  );
}
