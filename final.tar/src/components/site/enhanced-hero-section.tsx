'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useSpring, useReducedMotion } from 'framer-motion';
import { ArrowDown, Sparkles, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { generateAsciiHeader, architectAscii } from '@/lib/ascii';

const roles = [
  'Operations Analyst',
  'AI Practitioner', 
  'Systems Architect',
  'Author',
];

const asciiArt = `
    ╭────────────────────────────────────╮
    │                                    │
    │    ┏━━━━━━━━━━━━━━━━━━━━━━┓       │
    │    ┃   THE  ARCHITECT    ┃       │
    │    ┗━━━━━━━━━━━━━━━━━━━━━━┛       │
    │                                    │
    │    • Operations Analysis          │
    │    • AI & Automation              │
    │    • Systems Design               │
    │    • Human Potential              │
    │                                    │
    ╰────────────────────────────────────╯`;

export function EnhancedHeroSection() {
  const [displayedRole, setDisplayedRole] = useState(0);
  const [typedText, setTypedText] = useState('');
  const [showAscii, setShowAscii] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });
  
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.9]);

  // Role rotation
  useEffect(() => {
    if (prefersReducedMotion) return;
    const interval = setInterval(() => {
      setDisplayedRole(prev => (prev + 1) % roles.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [prefersReducedMotion]);

  // Typewriter effect for ASCII
  useEffect(() => {
    if (prefersReducedMotion) {
      setTypedText(asciiArt);
      setShowAscii(true);
      return;
    }
    
    const timeout = setTimeout(() => setShowAscii(true), 500);
    let charIndex = 0;
    
    const typeInterval = setInterval(() => {
      if (charIndex < asciiArt.length) {
        setTypedText(asciiArt.slice(0, charIndex + 1));
        charIndex++;
      } else {
        clearInterval(typeInterval);
      }
    }, 5);

    return () => {
      clearTimeout(timeout);
      clearInterval(typeInterval);
    };
  }, [prefersReducedMotion]);

  return (
    <section 
      ref={containerRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* ASCII Grid Background */}
      <div 
        className="absolute inset-0 opacity-[0.02] dark:opacity-[0.05]"
        aria-hidden="true"
      >
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Radial gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background pointer-events-none" />

      {/* Content */}
      <motion.div
        style={{ y: prefersReducedMotion ? 0 : y, opacity, scale }}
        className="editorial-container py-20 md:py-32 relative z-10"
      >
        <div className="max-w-4xl mx-auto">
          {/* ASCII Art Header */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: showAscii ? 1 : 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8 hidden lg:block"
          >
            <pre className="font-mono text-[10px] md:text-xs text-muted-foreground/50 leading-tight overflow-hidden">
              {typedText}
            </pre>
          </motion.div>

          {/* Mobile ASCII Marker */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center justify-center gap-2 mb-6 lg:hidden"
          >
            <span className="font-mono text-xs text-muted-foreground">{'[ '}</span>
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="font-mono text-sm">The Architect</span>
            <span className="font-mono text-xs text-muted-foreground">{' ]'}</span>
          </motion.div>

          {/* Main Title with ASCII decoration */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center"
          >
            {/* ASCII Top Decoration */}
            <div className="flex items-center justify-center gap-4 mb-4">
              <span className="font-mono text-lg text-muted-foreground/30">╭──</span>
              <span className="font-mono text-xs text-muted-foreground">DOUGLAS MITCHELL</span>
              <span className="font-mono text-lg text-muted-foreground/30">──╮</span>
            </div>

            <h1 className="editorial-title mb-2 relative">
              <span className="relative inline-block">
                Douglas
                <motion.span
                  className="absolute -right-8 top-0 font-mono text-2xl text-primary/30"
                  animate={{ rotate: [0, 10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  _
                </motion.span>
              </span>
              <br />
              <span className="text-primary">Mitchell</span>
            </h1>

            {/* ASCII Bottom Decoration */}
            <div className="flex items-center justify-center gap-4 mt-2 mb-6">
              <span className="font-mono text-lg text-muted-foreground/30">╰──</span>
              <span className="font-mono text-lg text-muted-foreground/30">{'═'.repeat(16)}</span>
              <span className="font-mono text-lg text-muted-foreground/30">──╯</span>
            </div>
          </motion.div>

          {/* Animated Role */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-center mb-6"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-muted/50 border border-border rounded-full">
              <span className="font-mono text-xs text-muted-foreground">$</span>
              <motion.span
                key={displayedRole}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-sm font-medium"
              >
                {roles[displayedRole]}
              </motion.span>
              <motion.span
                animate={{ opacity: [1, 0] }}
                transition={{ duration: 0.8, repeat: Infinity }}
                className="font-mono"
              >
                ▊
              </motion.span>
            </div>
          </motion.div>

          {/* Subtitle */}
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="editorial-subtitle max-w-2xl mx-auto mb-8 text-center"
          >
            Building systems at the intersection of{' '}
            <span className="text-foreground font-medium">technology</span> and{' '}
            <span className="text-foreground font-medium">human potential</span>.
            <br />
            <span className="text-sm text-muted-foreground">
              Author of <em>The Confident Mind</em>. Houston-based.
            </span>
          </motion.p>

          {/* Credentials */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-wrap justify-center gap-2 mb-10"
          >
            {[
              { label: 'Google AI', icon: '◆' },
              { label: 'Anthropic', icon: '◆' },
              { label: '85+ Repos', icon: '◆' },
            ].map((credential, i) => (
              <motion.div
                key={credential.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7 + i * 0.1 }}
                className="group flex items-center gap-2 px-3 py-1.5 text-sm font-medium bg-background border border-border rounded-full hover:border-primary/50 transition-colors cursor-default"
              >
                <span className="text-primary text-xs">{credential.icon}</span>
                {credential.label}
              </motion.div>
            ))}
          </motion.div>

          {/* CTA Buttons */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <motion.a 
              href="#work"
              className="cta-button group"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="font-mono text-xs opacity-70">01</span>
              View My Work
              <ArrowDown className="h-4 w-4 group-hover:translate-y-1 transition-transform" />
            </motion.a>
            <motion.a 
              href="#about"
              className="ghost-button group"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="font-mono text-xs opacity-70">02</span>
              Learn More
              <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </motion.a>
          </motion.div>

          {/* ASCII Footer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="mt-12 text-center"
          >
            <pre className="font-mono text-[8px] text-muted-foreground/30 inline-block">
{`─────✧─────✧─────✧─────`}
            </pre>
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="flex flex-col items-center gap-2"
        >
          <span className="font-mono text-xs text-muted-foreground">scroll</span>
          <div className="w-5 h-8 border border-muted-foreground/30 rounded-full flex justify-center">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
              className="w-1 h-1.5 bg-muted-foreground/50 rounded-full mt-2"
            />
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
