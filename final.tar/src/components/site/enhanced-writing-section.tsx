'use client';

import { useRef, useState } from 'react';
import { motion, useScroll, useTransform, useReducedMotion } from 'framer-motion';
import { ArrowRight, Clock, Tag, TrendingUp, Sparkles } from 'lucide-react';

const articles = [
  {
    title: 'Building AI-Powered Workflows That Actually Work',
    excerpt: 'A practical guide to implementing AI automation in your daily operations without falling into the hype trap.',
    category: 'Technical',
    readTime: '8 min',
    date: 'Jan 2025',
    featured: true,
    trending: true,
  },
  {
    title: 'The Architecture of Confidence',
    excerpt: 'How systems thinking applies to personal development and building lasting self-assurance.',
    category: 'Insight',
    readTime: '6 min',
    date: 'Dec 2024',
    featured: true,
    trending: false,
  },
  {
    title: 'From Operations to AI: A Career Transition Guide',
    excerpt: 'Practical steps for operations professionals looking to integrate AI into their skillset.',
    category: 'Essay',
    readTime: '10 min',
    date: 'Nov 2024',
    featured: false,
    trending: true,
  },
  {
    title: 'System Design for Solo Founders',
    excerpt: 'Building scalable systems as a one-person team without burning out.',
    category: 'Technical',
    readTime: '12 min',
    date: 'Oct 2024',
    featured: false,
    trending: false,
  },
];

const categories = ['All', 'Technical', 'Insight', 'Essay'];

export function EnhancedWritingSection() {
  const [activeCategory, setActiveCategory] = useState('All');
  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  });
  
  const x = useTransform(scrollYProgress, [0, 1], [-50, 50]);

  const filteredArticles = activeCategory === 'All' 
    ? articles 
    : articles.filter(a => a.category === activeCategory);

  return (
    <section id="writing" className="section-spacing relative overflow-hidden" ref={containerRef}>
      {/* Background Animation */}
      <motion.div 
        style={{ x: prefersReducedMotion ? 0 : x }}
        className="absolute top-1/2 left-0 font-mono text-[200px] text-muted-foreground/5 pointer-events-none select-none -translate-y-1/2"
      >
        WRITING
      </motion.div>

      <div className="editorial-container relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-4">
            <span className="font-mono text-xs text-muted-foreground">{'// 05'}</span>
            <div className="h-px flex-1 bg-gradient-to-r from-border to-transparent" />
          </div>
          
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div>
              <h2 className="editorial-title mb-4">
                Thoughts & Insights
              </h2>
              <p className="editorial-subtitle max-w-xl">
                Exploring the intersection of technology, operations, and human potential.
              </p>
            </div>

            {/* Category Filter */}
            <div className="flex gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 text-sm font-mono rounded-lg transition-all ${
                    activeCategory === category
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted hover:bg-muted/80'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Articles Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {filteredArticles.map((article, index) => (
            <motion.article
              key={article.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className={`group relative border border-border rounded-xl overflow-hidden bg-background ${
                article.featured ? 'md:col-span-2 lg:col-span-1' : ''
              }`}
            >
              {/* Top Accent */}
              <div className={`h-1 ${article.featured ? 'bg-gradient-to-r from-primary via-primary/50 to-primary' : 'bg-muted'}`} />

              {/* Content */}
              <div className="p-6">
                {/* Header */}
                <div className="flex items-center justify-between gap-4 mb-4">
                  <div className="flex items-center gap-2">
                    <Tag className="h-3 w-3 text-muted-foreground" />
                    <span className="font-mono text-xs text-muted-foreground uppercase tracking-wider">
                      {article.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {article.featured && (
                      <span className="flex items-center gap-1 px-2 py-0.5 text-xs font-mono bg-primary/10 text-primary rounded">
                        <Sparkles className="h-3 w-3" />
                        Featured
                      </span>
                    )}
                    {article.trending && (
                      <span className="flex items-center gap-1 px-2 py-0.5 text-xs font-mono bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded">
                        <TrendingUp className="h-3 w-3" />
                        Trending
                      </span>
                    )}
                  </div>
                </div>

                {/* Title */}
                <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                  {article.title}
                </h3>

                {/* Excerpt */}
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                  {article.excerpt}
                </p>

                {/* ASCII Divider */}
                <div className="flex items-center gap-2 mb-4 text-muted-foreground/30">
                  <span className="font-mono text-xs">{'─'.repeat(4)}</span>
                  <span className="font-mono text-xs">◈</span>
                  <span className="font-mono text-xs">{'─'.repeat(20)}</span>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-4">
                    <span>{article.date}</span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {article.readTime}
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-primary group-hover:translate-x-1 transition-transform">
                    Read <ArrowRight className="h-3 w-3" />
                  </span>
                </div>
              </div>

              {/* Hover Border Glow */}
              <div className="absolute inset-0 border-2 border-primary/0 group-hover:border-primary/20 rounded-xl transition-colors pointer-events-none" />
            </motion.article>
          ))}
        </div>

        {/* View All / Newsletter CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-12 p-6 border border-border rounded-xl bg-muted/30"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h4 className="font-semibold mb-1">Stay Updated</h4>
              <p className="text-sm text-muted-foreground">
                New articles and insights delivered to your inbox.
              </p>
            </div>
            <div className="flex gap-3 w-full md:w-auto">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 md:w-64 px-4 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:border-primary"
              />
              <button className="cta-button whitespace-nowrap">
                Subscribe
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
