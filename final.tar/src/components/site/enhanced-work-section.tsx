'use client';

import { useState, useRef } from 'react';
import { motion, useScroll, useTransform, useReducedMotion } from 'framer-motion';
import { ExternalLink, Github, Star, GitFork, ArrowUpRight, Terminal } from 'lucide-react';

const featuredProjects = [
  {
    title: 'AI Workflow Automation',
    description: 'Intelligent automation systems that streamline operations and reduce manual overhead. Built with modern AI integration patterns.',
    tech: ['Python', 'LangChain', 'OpenAI', 'n8n'],
    category: 'AI Automation',
    github: 'https://github.com/Senpai-Sama7',
    stars: 42,
    forks: 12,
    color: 'from-emerald-500/10 to-teal-500/10',
  },
  {
    title: 'The Confident Mind Platform',
    description: 'Digital platform companion for the book, featuring interactive exercises, progress tracking, and community features.',
    tech: ['Next.js', 'TypeScript', 'Prisma', 'Tailwind'],
    category: 'Web Development',
    github: 'https://github.com/Senpai-Sama7',
    stars: 38,
    forks: 8,
    color: 'from-violet-500/10 to-purple-500/10',
  },
  {
    title: 'Systems Architecture Toolkit',
    description: 'Collection of reusable patterns and tools for building scalable, maintainable systems. Documentation-first approach.',
    tech: ['TypeScript', 'Node.js', 'Docker', 'AWS'],
    category: 'System Design',
    github: 'https://github.com/Senpai-Sama7',
    stars: 56,
    forks: 15,
    color: 'from-amber-500/10 to-orange-500/10',
  },
];

const stats = [
  { label: 'Repositories', value: '85+' },
  { label: 'Stars Earned', value: '200+' },
  { label: 'Contributions', value: '500+' },
  { label: 'Languages', value: '12' },
];

export function EnhancedWorkSection() {
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);

  return (
    <section id="work" className="section-spacing relative overflow-hidden" ref={containerRef}>
      {/* Background decoration */}
      <motion.div 
        style={{ y: prefersReducedMotion ? 0 : y }}
        className="absolute inset-0 opacity-30 pointer-events-none"
      >
        <div className="absolute top-20 left-10 font-mono text-[120px] text-muted-foreground/5">
          &lt;/&gt;
        </div>
        <div className="absolute bottom-20 right-10 font-mono text-[100px] text-muted-foreground/5">
          { } [ ]
        </div>
      </motion.div>

      <div className="editorial-container relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <div className="flex items-center gap-3 mb-4">
            <span className="font-mono text-xs text-muted-foreground">{'// 02'}</span>
            <div className="h-px flex-1 bg-gradient-to-r from-border to-transparent" />
          </div>
          
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
            <div>
              <h2 className="editorial-title mb-4">
                Proof Architecture
              </h2>
              <p className="editorial-subtitle max-w-xl">
                85+ repositories of public proof. Real systems, real solutions, real impact.
              </p>
            </div>

            {/* Stats */}
            <div className="flex gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="font-mono text-2xl font-bold text-foreground">
                    {stat.value}
                  </div>
                  <div className="font-mono text-xs text-muted-foreground">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {featuredProjects.map((project, index) => (
            <motion.article
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              onHoverStart={() => setHoveredProject(project.title)}
              onHoverEnd={() => setHoveredProject(null)}
              className="group relative"
            >
              {/* Project Card */}
              <div className={`relative h-full border border-border rounded-xl overflow-hidden bg-gradient-to-br ${project.color} backdrop-blur-sm`}>
                {/* Terminal Header */}
                <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/30">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
                  </div>
                  <div className="flex-1 flex items-center justify-center">
                    <span className="font-mono text-xs text-muted-foreground">
                      {project.category.toLowerCase().replace(' ', '-')}
                    </span>
                  </div>
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    aria-label={`View ${project.title} on GitHub`}
                  >
                    <Github className="h-4 w-4" />
                  </a>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors flex items-center gap-2">
                    <Terminal className="h-4 w-4 text-muted-foreground" />
                    {project.title}
                  </h3>
                  
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {project.description}
                  </p>

                  {/* Tech Stack */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-0.5 text-xs font-mono bg-muted/50 rounded border border-border/50"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Stats */}
                  <div className="flex items-center justify-between pt-4 border-t border-border/50">
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1 hover:text-yellow-500 transition-colors">
                        <Star className="h-3.5 w-3.5" />
                        {project.stars}
                      </span>
                      <span className="inline-flex items-center gap-1 hover:text-primary transition-colors">
                        <GitFork className="h-3.5 w-3.5" />
                        {project.forks}
                      </span>
                    </div>
                    <motion.div
                      animate={{ 
                        x: hoveredProject === project.title ? 0 : -10,
                        opacity: hoveredProject === project.title ? 1 : 0 
                      }}
                      className="text-primary"
                    >
                      <ArrowUpRight className="h-4 w-4" />
                    </motion.div>
                  </div>
                </div>

                {/* Hover Border Effect */}
                <motion.div
                  className="absolute inset-0 border-2 border-primary rounded-xl pointer-events-none"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: hoveredProject === project.title ? 1 : 0 }}
                  transition={{ duration: 0.2 }}
                />
              </div>

              {/* ASCII Corner Decoration */}
              <div className="absolute -top-2 -left-2 font-mono text-xs text-muted-foreground/30 pointer-events-none">
                ╭
              </div>
              <div className="absolute -bottom-2 -right-2 font-mono text-xs text-muted-foreground/30 pointer-events-none">
                ╯
              </div>
            </motion.article>
          ))}
        </div>

        {/* View All CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <a
            href="https://github.com/Senpai-Sama7"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-6 py-3 border border-border rounded-full hover:border-primary/50 hover:bg-muted/30 transition-all group"
          >
            <Github className="h-5 w-5" />
            <span>View All Projects on GitHub</span>
            <ExternalLink className="h-4 w-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        </motion.div>

        {/* ASCII Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-16 text-center font-mono text-xs text-muted-foreground/30"
        >
          {'/* Built with passion. Shipped with confidence. */'}
        </motion.div>
      </div>
    </section>
  );
}
