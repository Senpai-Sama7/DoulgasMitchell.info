'use client';

import { motion, useReducedMotion } from 'framer-motion';
import { Award, ExternalLink } from 'lucide-react';

const certifications = [
  {
    title: 'Google AI Professional Certificate',
    issuer: 'Google',
    description: 'Comprehensive AI professional certification covering machine learning fundamentals, AI development, and responsible AI practices.',
    credentialUrl: 'https://www.credly.com/users/douglas-mitchell.887417ae/badges',
    featured: true,
  },
  {
    title: 'Anthropic AI Safety',
    issuer: 'Anthropic',
    description: 'Certification in AI safety principles, responsible AI development, and ethical AI deployment practices.',
    credentialUrl: 'https://www.credly.com/users/douglas-mitchell.887417ae/badges',
    featured: true,
  },
];

export function CertificationsSection() {
  const shouldReduceMotion = useReducedMotion();

  return (
    <section className="section-spacing">
      <div className="editorial-container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="ascii-marker mb-4 justify-center">
            <Award className="h-3 w-3" />
            <span>Credentials</span>
          </div>
          <h2 className="editorial-title mb-4">
            Certifications
          </h2>
          <p className="editorial-subtitle max-w-xl mx-auto">
            Continuous learning in emerging technologies. Verified credentials in AI and professional development.
          </p>
        </motion.div>

        {/* Certifications Grid */}
        <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {certifications.map((cert, index) => (
            <motion.a
              key={cert.title}
              href={cert.credentialUrl}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group block p-6 border border-border rounded-lg bg-background hover:border-primary/30 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <Award className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="font-mono text-xs text-muted-foreground uppercase tracking-wider">
                    {cert.issuer}
                  </span>
                  <h3 className="font-semibold mt-1 group-hover:text-primary transition-colors">
                    {cert.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                    {cert.description}
                  </p>
                  <span className="inline-flex items-center gap-1 text-xs text-primary mt-3 group-hover:translate-x-1 transition-transform">
                    View Credential
                    <ExternalLink className="h-3 w-3" />
                  </span>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
