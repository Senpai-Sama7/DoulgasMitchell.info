'use client';

import Link from 'next/link';
import { Github, Linkedin, Mail, BookOpen } from 'lucide-react';

const footerLinks = {
  navigation: [
    { href: '#about', label: 'About' },
    { href: '#work', label: 'Work' },
    { href: '#writing', label: 'Writing' },
    { href: '#contact', label: 'Contact' },
  ],
  external: [
    { href: 'https://github.com/Senpai-Sama7', label: 'GitHub', icon: Github },
    { href: 'https://www.linkedin.com/in/douglas-mitchell-the-architect/', label: 'LinkedIn', icon: Linkedin },
    { href: 'https://www.amazon.com/Confident-Mind-Practical-Authentic-Confidence-ebook/dp/B0FPJPPPC9', label: 'Book', icon: BookOpen },
  ],
};

export function SiteFooter() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-muted/30">
      <div className="editorial-container py-12 md:py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 mb-12">
          {/* Brand Column */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <span className="font-mono text-xs text-muted-foreground">{'//'}</span>
              <span className="font-semibold">Douglas Mitchell</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              Operations Analyst, AI Practitioner, and Author building systems at the intersection of technology and human potential.
            </p>
          </div>

          {/* Navigation Column */}
          <div>
            <h4 className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-4">
              Navigation
            </h4>
            <ul className="space-y-2">
              {footerLinks.navigation.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect Column */}
          <div>
            <h4 className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-4">
              Connect
            </h4>
            <ul className="space-y-2">
              {footerLinks.external.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm text-foreground hover:text-primary transition-colors"
                  >
                    <link.icon className="h-4 w-4" />
                    {link.label}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="mailto:contact@douglasmitchell.info"
                  className="inline-flex items-center gap-2 text-sm text-foreground hover:text-primary transition-colors"
                >
                  <Mail className="h-4 w-4" />
                  Email
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* ASCII Divider */}
        <div className="ascii-divider mb-8">
          {'─'.repeat(3)}
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground">
          <p>
            © {currentYear} Douglas Mitchell. All rights reserved.
          </p>
          <p className="font-mono">
            Built with precision. Designed with intent.
          </p>
        </div>
      </div>
    </footer>
  );
}
