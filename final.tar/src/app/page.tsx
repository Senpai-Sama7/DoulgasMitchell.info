'use client';

import { useScroll, useReducedMotion } from 'framer-motion';
import { useState, useEffect, useCallback, useSyncExternalStore } from 'react';
import {
  SiteHeader,
  SiteFooter,
  EnhancedHeroSection,
  EnhancedAboutSection,
  EnhancedWorkSection,
  EnhancedBookSection,
  EnhancedWritingSection,
  EnhancedContactSection,
  CertificationsSection,
} from '@/components/site';
import { CommandPalette, CommandKTrigger } from '@/components/effects';

// Theme store for consistent theme management
function createThemeStore() {
  let listeners: Array<() => void> = [];
  let isDark = false;

  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    isDark = stored === 'dark' || (!stored && prefersDark);
  }

  return {
    subscribe: (listener: () => void) => {
      listeners.push(listener);
      return () => {
        listeners = listeners.filter(l => l !== listener);
      };
    },
    getSnapshot: () => isDark,
    getServerSnapshot: () => false,
    toggle: () => {
      isDark = !isDark;
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
      document.documentElement.classList.toggle('dark', isDark);
      listeners.forEach(l => l());
    },
    init: () => {
      if (typeof window !== 'undefined') {
        document.documentElement.classList.toggle('dark', isDark);
      }
    }
  };
}

const themeStore = createThemeStore();

export default function Home() {
  const { scrollYProgress } = useScroll();
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const prefersReducedMotion = useReducedMotion();
  
  const isDark = useSyncExternalStore(
    themeStore.subscribe,
    themeStore.getSnapshot,
    themeStore.getServerSnapshot
  );

  // Initialize theme once on mount
  useEffect(() => {
    themeStore.init();
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsCommandOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const toggleTheme = useCallback(() => {
    themeStore.toggle();
  }, []);

  const handleNavigate = useCallback((href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth' });
    }
  }, [prefersReducedMotion]);

  return (
    <>
      {/* Scroll Progress Indicator */}
      <div
        className="scroll-progress"
        style={{ 
          transform: `scaleX(${typeof window !== 'undefined' ? scrollYProgress.get() : 0})`,
          background: isDark ? '#fafafa' : '#171717'
        }}
      />

      {/* Header */}
      <SiteHeader />

      {/* Main Content */}
      <main id="main-content" className="flex-1">
        {/* Hero Section */}
        <EnhancedHeroSection />

        {/* ASCII Divider */}
        <div className="editorial-container">
          <div className="flex items-center justify-center gap-4 py-8">
            <span className="font-mono text-muted-foreground/20 text-xl">{'═'.repeat(20)}</span>
            <span className="font-mono text-muted-foreground/30">◈</span>
            <span className="font-mono text-muted-foreground/20 text-xl">{'═'.repeat(20)}</span>
          </div>
        </div>

        {/* About Section */}
        <EnhancedAboutSection />

        {/* Work Section */}
        <EnhancedWorkSection />

        {/* Book Section */}
        <EnhancedBookSection />

        {/* Writing Section */}
        <EnhancedWritingSection />

        {/* Certifications Section */}
        <CertificationsSection />

        {/* Contact Section */}
        <EnhancedContactSection />
      </main>

      {/* Footer */}
      <SiteFooter />

      {/* Command Palette */}
      <CommandPalette
        isOpen={isCommandOpen}
        onClose={() => setIsCommandOpen(false)}
        onNavigate={handleNavigate}
        isDark={isDark}
        onToggleTheme={toggleTheme}
      />

      {/* Command K Trigger */}
      <CommandKTrigger onClick={() => setIsCommandOpen(true)} />
    </>
  );
}
