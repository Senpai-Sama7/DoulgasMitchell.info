import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, message, source } = body;

    // Validate required fields
    if (!name || !email || !message) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      );
    }

    // Store in database (when database is available)
    try {
      await db.contactSubmission.create({
        data: {
          name,
          email,
          message,
          source: source || 'website',
          status: 'new',
        },
      });
    } catch {
      // If database fails, still return success but log
      console.log('Contact submission:', { name, email, message });
    }

    return NextResponse.json({
      success: true,
      message: 'Contact submission received',
    });
  } catch (error) {
    console.error('Contact submission error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Contact API endpoint. Use POST to submit contact forms.',
  });
}
